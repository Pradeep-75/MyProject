﻿using FleetMS.Application.DTO.Auth;
using Microsoft.AspNetCore.Authorization;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using FleetMS.Infrastructure.Project.Auth;
using FleetMS.Application;

namespace FleetMS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
       
        public class AuthController : ControllerBase
        {
            private readonly IConfiguration _config;
            private readonly IAuth _auth;
            private readonly ErrorHandler _errorhandling;

            public AuthController(IConfiguration config, IAuth auth, ErrorHandler errorhandling)
            {
                _config = config;
                _auth = auth;
                _errorhandling= errorhandling;
            }

            [HttpPost("login")]
            [AllowAnonymous]
            public IActionResult Login([FromBody] AuthRequestDTO request)
            {
                try
                {
                    if (request == null || string.IsNullOrWhiteSpace(request.Name) || string.IsNullOrWhiteSpace(request.Licensenumber))
                    {
                        return BadRequest(new { message = "Name and Licensenumber are required" });
                    }

                    var user = _auth.ValidateDriver(request.Name, request.Licensenumber);

                    if (user == null)
                    {
                        return Unauthorized(new { message = "Invalid Name or Licensenumber" });
                    }

                    // JWT settings
                    var jwtSettings = _config.GetSection("Jwt");
                    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings["Key"]));
                    var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                    var claims = new[]
                        {
                        new Claim(ClaimTypes.NameIdentifier, user.Driverid.ToString()),
                        new Claim(ClaimTypes.Name, user.Name ?? ""),
                        new Claim(ClaimTypes.Role, user.Licensenumber ?? "") // ✅ Correct
                    };


                    var token = new JwtSecurityToken(
                        issuer: jwtSettings["Issuer"],
                        audience: jwtSettings["Audience"],
                        claims: claims,
                        expires: DateTime.Now.AddMinutes(Convert.ToDouble(jwtSettings["ExpiresMinutes"])),
                        signingCredentials: creds
                    );

                    return Ok(new { token = new JwtSecurityTokenHandler().WriteToken(token) });
                }
                catch (Exception ex)
                {
                    // Option 1: Return raw error (for debugging only)
                    // return StatusCode(StatusCodes.Status500InternalServerError, new { message = ex.Message });

                    // Option 2: Use your custom errorhandling class
                    return StatusCode(StatusCodes.Status500InternalServerError,
                        new { message = "An unexpected error occurred while processing your request." });
                }
            }

        }
    
}
