﻿using FleetMS.Application;
using FleetMS.Application.DTO.Driver;
using FleetMS.Infrastructure.Project.Drivers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace FleetMS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class DriverController : ControllerBase
    {
        private readonly IDriversTable driversTable;
        public DriverController(IDriversTable _driversTable)
        {
            driversTable = _driversTable;
        }

        [HttpPost]
        [Route("AddDrivers")]
        public IActionResult AddDrivers(AddDriversDTO addDriversDTO)
        {
            addDriversDTO.Licensenumber = EncryptHasher.HashPassword(addDriversDTO.Licensenumber);
            return Ok(driversTable.AddDrivers(addDriversDTO));
        }

        [HttpGet]
        [Route("GetAllDrivers")]
        public IActionResult GetAllDrivers()
        {
            return Ok(driversTable.GetAllDrivers());
        }

        [HttpPut]
        [Route("UpdateDrivers")]
        public IActionResult UpdateDrivers(UpdateDriverDTO updateDriverDTO)
        {
            updateDriverDTO.Licensenumber = EncryptHasher.HashPassword(updateDriverDTO.Licensenumber);
            return Ok(driversTable.UpdateDrivers(updateDriverDTO));
        }

        [HttpDelete]
        [Route("DeleteDrivers")]
        public IActionResult DeleteDrivers(int Driverid)
        {
            return Ok(driversTable.DeleteDrivers(Driverid));
        }
    }
}
