﻿using FleetMS.Infrastructure.Project.Aggregate;
using FleetMS.Infrastructure.Project.Trips;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FleetMS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class GetAggregateController : ControllerBase
    {
        private readonly IGetAggregate Aggregate;
        public GetAggregateController(IGetAggregate _Aggregate)
        {
            Aggregate = _Aggregate;
        }


        [HttpGet]
        [Route("Aggregates")]
        public IActionResult Aggregates()
        {
            try
            {
                var result = Aggregate.Aggregates();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
