﻿using FleetMS.Infrastructure.Models;
using FleetMS.Infrastructure.Project.Tracker;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FleetMS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class TrackController : ControllerBase
    {
        private readonly ITracker tracker;
        public TrackController(ITracker _tracker)
        {
            tracker= _tracker;
        }

        [HttpGet]
        [Route("GetAllDetails")]
        public IActionResult GetAllDetails(int driverid)
        {
            return Ok(tracker.GetAllDetails(driverid));
        }

        [HttpDelete("DeleteVehicle/{vehicleid}")]
        public IActionResult DeleteVehicle(int vehicleid)
        {
            return Ok(tracker.DeleteVehicle(vehicleid));
        }
    }
}
