﻿using System.Security.Claims;
using FleetMS.Application;
using FleetMS.Application.DTO.Tracker;
using FleetMS.Infrastructure.Models;
using FleetMS.Infrastructure.Project.Tracker;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FleetMS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class TrackController : ControllerBase
    {
        private readonly ITracker tracker;
        public TrackController(ITracker _tracker)
        {
            tracker = _tracker;
        }

        [HttpPost]
        [Route("AddVehicle")]
        public IActionResult AddVehicle([FromBody] CreateVehicleDTO create)
        {
            try
            {
                var result = tracker.AddVehicle(create);  // calls your service/repository
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [HttpGet]
        [Route("GetByIdVehicle")]
        public IActionResult GetByIdVehicle([FromQuery] int driverid)
        {
            try
            {
                var vehicles = tracker.GetByIdVehicle(driverid);
                return Ok(vehicles);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetAllVehicles")]
        public IActionResult GetAllVehicles()
        {
            try
            {
                return Ok(tracker.GetAllVehicles());
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [HttpDelete]
        [Route("DeleteVehicle/{vehicleid}")]
        public IActionResult DeleteVehicle(int vehicleid)
        {
            try
            {
                return Ok(tracker.DeleteVehicle(vehicleid));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpPut]
        [Route("UpdateVehicle")]
        public IActionResult UpdateVehicle(UpdateVehicleDTO update)
        {
            try
            {
                return Ok(tracker.UpdateVehicle(update));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
