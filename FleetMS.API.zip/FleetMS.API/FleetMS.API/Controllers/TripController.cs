﻿using FleetMS.Application.DTO.Tracker;
using System.Diagnostics;
using FleetMS.Application.DTO.Trip;
using FleetMS.Infrastructure.Project.Drivers;
using FleetMS.Infrastructure.Project.Tracker;
using FleetMS.Infrastructure.Project.Trips;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FleetMS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class TripController : ControllerBase
    {
        private readonly ITripTable TripTable;
        public TripController(ITripTable _TripTable)
        {
            TripTable = _TripTable;
        }

        [HttpGet]
        [Route("GetAllTrips")]
        public IActionResult GetAllTrips()
        {
            var result = TripTable.GetAllTrips();
            return Ok(result);
        }

        [HttpDelete]
        [Route("DeleteTrip/{tripid}")]
        public IActionResult DeleteTrip(int tripid)
        {
            var result = TripTable.DeleteTrip(tripid);
            return Ok(result);
        }

        [HttpPut]
        [Route("UpdateTrip")]
        public IActionResult UpdateTrip(UpdateTripDTO update)
        {
            try
            {
                return Ok(TripTable.UpdateTrip(update));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("AddTrip")]
        public IActionResult AddTrip([FromBody] CreateTripDTO create)
        {
            var result = TripTable.AddTrip(create);
            return Ok(result);
        }
    }
}
