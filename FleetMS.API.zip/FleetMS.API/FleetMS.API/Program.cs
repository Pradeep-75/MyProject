using System.Text;
using FleetMS.Application;
using FleetMS.Infrastructure.Models;
using FleetMS.Infrastructure.Project.Auth;
using FleetMS.Infrastructure.Project.Drivers;
using FleetMS.Infrastructure.Project.Tracker;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

// Read Db connection
var connectionString = builder.Configuration.GetConnectionString("DBConnectionString");

// Connect db connection to context file
builder.Services.AddDbContext<StarkPradeepContext>(option =>
    option.UseNpgsql(connectionString));

// Add services to the container
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// DI UserTable register
builder.Services.AddTransient<IDriversTable, DriversTable>(); //Driver

builder.Services.AddTransient<ITracker, Tracker>(); //Tracker

builder.Services.AddTransient<IAuth, Auth>(); //Auth
builder.Services.AddSingleton<ErrorHandler>(sp =>
{
    var env = sp.GetRequiredService<IWebHostEnvironment>();
    var logPath = Path.Combine(env.ContentRootPath, "wwwroot", "logs", "errors.txt");

    // ensure logs folder exists
    Directory.CreateDirectory(Path.GetDirectoryName(logPath)!);

    return new ErrorHandler(logPath);
});


// Swagger + JWT
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>

{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "My API", Version = "v1" });

    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "Enter 'Bearer' [space] and then your valid token"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
            },
            Array.Empty<string>()
        }
    });
});

// JWT configuration
var jwtSettings = builder.Configuration.GetSection("Jwt");
var key = Encoding.UTF8.GetBytes(jwtSettings["Key"]);
builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateIssuerSigningKey = true,
            ValidateLifetime = true,
            ValidIssuer = jwtSettings["Issuer"],
            ValidAudience = jwtSettings["Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(key)
        };
    });


//Make JSON case-insensitive (better for APIs)
var app = builder.Build();


// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthentication();  // ? Important: Must be before UseAuthorization
app.UseAuthorization();

// Enable serving wwwroot static files
app.UseStaticFiles();

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
