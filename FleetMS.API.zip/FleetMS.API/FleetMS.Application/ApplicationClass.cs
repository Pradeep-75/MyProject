﻿namespace FleetMS.Application
{
    public class ApplicationClass
    {

    }
}
