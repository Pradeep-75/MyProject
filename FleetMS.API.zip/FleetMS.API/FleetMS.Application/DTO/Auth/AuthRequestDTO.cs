﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetMS.Application.DTO.Auth
{
    public class AuthRequestDTO
    {
        public string Name { get; set; }

        public string Licensenumber { get; set; }
    }
}
