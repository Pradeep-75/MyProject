﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetMS.Application.DTO.Driver
{
    public class UpdateDriverDTO
    {
        public int Driverid { get; set; }

        public string Name { get; set; } = null!;

        public string Licensenumber { get; set; } = null!;

        public string? Phone { get; set; }

        public string? Address { get; set; }

        public DateTime? Createdon { get; set; }

        public int? Createdby { get; set; }

        public DateTime? Modifiedon { get; set; }

        public int? Modifiedby { get; set; }

        public bool? Isactive { get; set; }
    }
}
