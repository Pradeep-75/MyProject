﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetMS.Application.DTO.Aggregate
{
    public class GetAggregateDTO
    {
        public int DriverId { get; set; }
        public string DriverName { get; set; } = null!;
        public int VehicleCount { get; set; }
        public int TripCount { get; set; }
        public decimal TotalDistance { get; set; }
        public decimal AverageDistance { get; set; }
        public decimal MinDistance { get; set; }
        public decimal MaxDistance { get; set; }
    }
}
