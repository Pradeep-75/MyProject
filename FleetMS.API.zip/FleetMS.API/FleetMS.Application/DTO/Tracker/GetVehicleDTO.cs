﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetMS.Application.DTO.Tracker
{
    public class GetVehicleDTO
    {
        public int Vehicleid { get; set; }

        public int? Driverid { get; set; }

        public string Registrationnumber { get; set; } = null!;

        public string Model { get; set; } = null!;

        public string? Manufacturer { get; set; }

        public int? Year { get; set; }

        public string? Capacity { get; set; }

        public string? Status { get; set; }

        public DateTime? Createdon { get; set; }

        public int? Createdby { get; set; }

        public DateTime? Modifiedon { get; set; }

        public int? Modifiedby { get; set; }

        public bool? Isactive { get; set; }
    }
}
