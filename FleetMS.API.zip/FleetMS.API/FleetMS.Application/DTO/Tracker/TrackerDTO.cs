﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetMS.Application.DTO.Tracker
{
    public class TrackDriverDTO
    {
        public int Driverid { get; set; }
        public string Name { get; set; } = null!;
        public List<TrackVehicleDTO>? VehicleInfo { get; set; }
    }

    public class TrackVehicleDTO
    {
        public List<string> Trips { get; set; } = new();
        public int? Vehicle { get; set; }
    }
}
