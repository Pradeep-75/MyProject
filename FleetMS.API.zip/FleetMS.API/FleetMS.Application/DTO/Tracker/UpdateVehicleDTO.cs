﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetMS.Application.DTO.Tracker
{
    public class UpdateVehicleDTO
    {
        public int Vehicleid { get; set; }

        public string Registrationnumber { get; set; } = null!;

        public string Model { get; set; } = null!;

        public string? Manufacturer { get; set; }

        public int? Year { get; set; }

        public string? Capacity { get; set; }

        public string? Status { get; set; }

    }
}
