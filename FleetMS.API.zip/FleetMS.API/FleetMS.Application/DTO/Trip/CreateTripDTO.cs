﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetMS.Application.DTO.Trip
{
    public class CreateTripDTO
    {
        public int Vehicleid { get; set; }
        public string? Startlocation { get; set; }
        public string? Endlocation { get; set; }
        public decimal? Distancekm { get; set; }
        public string? Status { get; set; }
        public DateTime? Createdon { get; set; }
        public int? Createdby { get; set; }
    }
}
