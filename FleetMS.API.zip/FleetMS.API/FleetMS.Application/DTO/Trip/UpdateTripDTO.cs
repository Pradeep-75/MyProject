﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetMS.Application.DTO.Trip
{
    public class UpdateTripDTO
    {
        public int Tripid { get; set; }
        public string? Startlocation { get; set; }
        public string? Endlocation { get; set; }
        public decimal? Distancekm { get; set; }
        public string? Status { get; set; }
        public DateTime? Modifiedon { get; set; }
        public int? Modifiedby { get; set; }
    }
}
