﻿namespace FleetMS.Domain
{
    public class DomainClass
    {

    }
}
