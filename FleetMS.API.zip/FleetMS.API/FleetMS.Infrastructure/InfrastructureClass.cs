﻿namespace FleetMS.Infrastructure
{
    public class InfrastructureClass
    {

    }
}
