﻿using System;
using System.Collections.Generic;

namespace FleetMS.Infrastructure.Models;

public partial class Driver
{
    public int Driverid { get; set; }

    public string Name { get; set; } = null!;

    public string Licensenumber { get; set; } = null!;

    public string? Phone { get; set; }

    public string? Address { get; set; }

    public DateTime? Createdon { get; set; }

    public int? Createdby { get; set; }

    public DateTime? Modifiedon { get; set; }

    public int? Modifiedby { get; set; }

    public bool? Isactive { get; set; }

    public virtual ICollection<Vehicle> Vehicles { get; set; } = new List<Vehicle>();
}
