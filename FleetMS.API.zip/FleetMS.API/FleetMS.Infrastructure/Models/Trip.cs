﻿using System;
using System.Collections.Generic;

namespace FleetMS.Infrastructure.Models;

public partial class Trip
{
    public int Tripid { get; set; }

    public int? Vehicleid { get; set; }

    public string? Startlocation { get; set; }

    public string? Endlocation { get; set; }

    public decimal? Distancekm { get; set; }

    public string? Status { get; set; }

    public DateTime? Createdon { get; set; }

    public int? Createdby { get; set; }

    public DateTime? Modifiedon { get; set; }

    public int? Modifiedby { get; set; }

    public virtual Vehicle? Vehicle { get; set; }
}
