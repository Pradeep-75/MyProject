﻿using System;
using System.Collections.Generic;

namespace FleetMS.Infrastructure.Models;

public partial class Vehicle
{
    public int Vehicleid { get; set; }

    public int? Driverid { get; set; }

    public string Registrationnumber { get; set; } = null!;

    public string Model { get; set; } = null!;

    public string? Manufacturer { get; set; }

    public int? Year { get; set; }

    public string? Capacity { get; set; }

    public string? Status { get; set; }

    public DateTime? Createdon { get; set; }

    public int? Createdby { get; set; }

    public DateTime? Modifiedon { get; set; }

    public int? Modifiedby { get; set; }

    public bool? Isactive { get; set; }

    public virtual Driver? Driver { get; set; }

    public virtual ICollection<Trip> Trips { get; set; } = new List<Trip>();
}
