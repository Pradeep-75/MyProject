﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FleetMS.Application;
using FleetMS.Application.DTO.Aggregate;
using FleetMS.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;

namespace FleetMS.Infrastructure.Project.Aggregate
{
    public class GetAggregate : IGetAggregate
    {
        private readonly ErrorHandler _errorhandling;
        private readonly StarkPradeepContext SPContext;
        public GetAggregate(StarkPradeepContext UserTable, ErrorHandler errors)
        {
            SPContext = UserTable;
            _errorhandling = errors;
        }
        public List<GetAggregateDTO> Aggregates()
        {
            try
            {
                var result = SPContext.Drivers
                    .Include(d => d.Vehicles)
                        .ThenInclude(v => v.Trips)
                    .Select(driver => new GetAggregateDTO
                    {
                        DriverId = driver.Driverid,
                        DriverName = driver.Name,
                        VehicleCount = driver.Vehicles.Count,
                        TripCount = driver.Vehicles.SelectMany(v => v.Trips).Count(),

                        TotalDistance = driver.Vehicles.SelectMany(v => v.Trips)
                                          .Sum(t => t.Distancekm ?? 0),

                        AverageDistance = driver.Vehicles.SelectMany(v => v.Trips).Any()
                                          ? driver.Vehicles.SelectMany(v => v.Trips)
                                               .Average(t => t.Distancekm ?? 0)
                                          : 0,

                        MinDistance = driver.Vehicles.SelectMany(v => v.Trips).Any()
                                          ? driver.Vehicles.SelectMany(v => v.Trips)
                                               .Min(t => t.Distancekm ?? 0)
                                          : 0,

                        MaxDistance = driver.Vehicles.SelectMany(v => v.Trips).Any()
                                          ? driver.Vehicles.SelectMany(v => v.Trips)
                                               .Max(t => t.Distancekm ?? 0)
                                          : 0
                    })
                    .ToList();

                return result;
            }
            catch (Exception ex)
            {
                _errorhandling.Add(ex, "Error calculating aggregates with joins");
                return new List<GetAggregateDTO>();
            }
        }
    }
}
