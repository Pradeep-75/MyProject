﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FleetMS.Application.DTO.Aggregate;

namespace FleetMS.Infrastructure.Project.Aggregate
{
    public interface IGetAggregate
    {
        public List<GetAggregateDTO> Aggregates();
    }
}
