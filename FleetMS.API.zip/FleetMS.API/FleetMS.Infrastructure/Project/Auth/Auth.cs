﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FleetMS.Application;
using FleetMS.Infrastructure.Models;

namespace FleetMS.Infrastructure.Project.Auth
{
    public class Auth : IAuth
    {
        private readonly ErrorHandler _errorhandling;
        private readonly StarkPradeepContext _context;
        public Auth(StarkPradeepContext context, ErrorHandler errors)
        {
            _context = context;
            _errorhandling = errors;
        }

        public Driver ValidateDriver(string Username, string LicenseNumber)
        {
            try
            {
                var user = _context.Drivers.FirstOrDefault(u => u.Name == Username);
                if (user == null)
                {
                    return null;
                }

                // Just compare directly
                bool result = LicenseNumber == user.Licensenumber;

                return result ? user : null;
            }
            catch (Exception ex)
            {
                _errorhandling.Add(ex, "Error in Auth.ValidateDriver");
                throw;
            }
        }
    }
}
