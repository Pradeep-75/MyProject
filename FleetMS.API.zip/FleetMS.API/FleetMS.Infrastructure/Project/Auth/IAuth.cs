﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FleetMS.Infrastructure.Models;

namespace FleetMS.Infrastructure.Project.Auth
{
    public interface IAuth
    {
        Driver ValidateDriver(string Name, string Licensenumber);
    }
}
