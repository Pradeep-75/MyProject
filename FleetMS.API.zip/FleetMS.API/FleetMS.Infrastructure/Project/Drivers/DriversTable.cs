﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FleetMS.Application;
using FleetMS.Application.DTO.Driver;
using FleetMS.Infrastructure.Models;

namespace FleetMS.Infrastructure.Project.Drivers
{
    public class DriversTable : IDriversTable
    {
        private readonly ErrorHandler _errorhandling;
        private readonly StarkPradeepContext SPContext;
        public DriversTable(StarkPradeepContext UserTable, ErrorHandler errors)
        {
            SPContext = UserTable;
            _errorhandling = errors;
        }
        public string AddDrivers(AddDriversDTO addDriversDTO)
        {
            try
            {
                // Correctly instantiate the Userdetail object and assign properties
                var user = new Driver
                {
                    Name = addDriversDTO.Name,
                    Licensenumber = addDriversDTO.Licensenumber,
                    Phone = addDriversDTO.Phone,
                    Address = addDriversDTO.Address,
                    Createdon = DateTime.Now,
                    Createdby = addDriversDTO.Createdby,
                    Modifiedon = DateTime.Now,
                    Modifiedby = addDriversDTO.Modifiedby,
                    Isactive = addDriversDTO.Isactive
                };
                SPContext.Drivers.Add(user);
                SPContext.SaveChanges();
                return "Added Successfully";
            }
            catch (Exception ex)
            {
                _errorhandling.Add(ex, "Added Failed");
                throw ex;
            }
        }

        public string DeleteDrivers(int Driverid)
        {
            try
            {
                var user = SPContext.Drivers.FirstOrDefault(x => x.Driverid == Driverid);
                if (user != null)
                {
                    SPContext.Drivers.Remove(user);
                    SPContext.SaveChanges();
                    return "Delete Successfully";
                }
                else
                {
                    return "User Not Found";
                }
            }
            catch (Exception ex)
            {
                _errorhandling.Add(ex, "User Not Found");
                throw ex;
            }
        }

        public List<Driver> GetAllDrivers()
        {
            try
            {
                return SPContext.Drivers.ToList();
            }
            catch (Exception ex)
            {
                _errorhandling.Add(ex,"Success");
                return new List<Driver>();
            }
        }

        public string UpdateDrivers(UpdateDriverDTO updateDriverDTO)
        {
            try
            {
                if (updateDriverDTO != null && updateDriverDTO.Driverid > 0)
                {
                    var Users = SPContext.Drivers.FirstOrDefault(x => x.Driverid == updateDriverDTO.Driverid);
                    if (Users != null)
                    {
                        Users.Name = updateDriverDTO.Name;
                        Users.Licensenumber = updateDriverDTO.Licensenumber;
                        Users.Phone = updateDriverDTO.Phone;
                        Users.Address = updateDriverDTO.Address;

                        SPContext.SaveChanges();
                        return "Update Successfully";
                    }
                    else
                    {
                        return "User Not Found";
                    }
                }
                else
                {
                    return "Invalid Input";
                }
            }
            catch (Exception ex)
            {
                _errorhandling.Add(ex, "Update Failed");
                throw ex;
            }
        }
    }
}
