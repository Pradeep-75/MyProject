﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FleetMS.Infrastructure.Models;
using FleetMS.Application.DTO.Driver;


namespace FleetMS.Infrastructure.Project.Drivers
{
    public interface IDriversTable
    {
        List<Driver> GetAllDrivers();
        string AddDrivers(AddDriversDTO addDriversDTO);
        string UpdateDrivers(UpdateDriverDTO updateDriverDTO);
        string DeleteDrivers(int Driverid);
    }
}
