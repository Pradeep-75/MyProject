﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FleetMS.Application.DTO.Tracker;
using FleetMS.Infrastructure.Models;

namespace FleetMS.Infrastructure.Project.Tracker
{
    public interface ITracker
    {
        List<GetVehicleDTO> GetByIdVehicle(int driverid);
        List<Vehicle> GetAllVehicles();
        public string DeleteVehicle(int vehicleid);
        public string UpdateVehicle (UpdateVehicleDTO update);
        public string AddVehicle(CreateVehicleDTO Create);
    }
}
