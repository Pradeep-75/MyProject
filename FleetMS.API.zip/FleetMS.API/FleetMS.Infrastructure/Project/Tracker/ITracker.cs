﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FleetMS.Application.DTO.Tracker;

namespace FleetMS.Infrastructure.Project.Tracker
{
    public interface ITracker
    {
        List<TrackDriverDTO> GetAllDetails(int driverid);
        public string DeleteVehicle(int vehicleid);
    }
}
