﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FleetMS.Application;
using FleetMS.Application.DTO.Tracker;
using FleetMS.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;

namespace FleetMS.Infrastructure.Project.Tracker
{
    public class Tracker : ITracker
    {
        private readonly ErrorHandler _errorhandling;
        private readonly StarkPradeepContext SPContext;
        public Tracker(StarkPradeepContext _SPContext, ErrorHandler errors)
        {
            SPContext = _SPContext;
            _errorhandling = errors;
        }

        public string AddVehicle(CreateVehicleDTO Create)
        {
            try
            {
                var vehicle = new Vehicle
                {
                    Registrationnumber = Create.Registrationnumber,
                    Model = Create.Model,
                    Manufacturer = Create.Manufacturer,
                    Year = Create.Year,
                    Capacity = Create.Capacity,
                    Status = Create.Status,
                    Driverid = Create.Driverid
                };

                SPContext.Vehicles.Add(vehicle);
                SPContext.SaveChanges();

                return "Vehicle added successfully";
            }
            catch (Exception ex)
            {
                _errorhandling.Add(ex, "Error adding vehicle");
                return "Error adding vehicle";
            }
        }

        public List<GetVehicleDTO> GetByIdVehicle(int driverid)
        {
            try
            {
                var vehicles = SPContext.Vehicles
                    .Where(v => v.Driverid == driverid)   // filter by driverid
                    .Select(v => new GetVehicleDTO
                    {
                        Vehicleid = v.Vehicleid,
                        Registrationnumber = v.Registrationnumber,
                        Model = v.Model,
                        Manufacturer = v.Manufacturer,
                        Year = v.Year,
                        Capacity = v.Capacity,
                        Status = v.Status
                    })
                    .ToList();

                return vehicles;
            }
            catch (Exception ex)
            {
                _errorhandling.Add(ex, "Error fetching vehicles");
                return new List<GetVehicleDTO>();
            }
        }


        public string DeleteVehicle(int vehicleid)
        {
            try
            {
                var existing = SPContext.Vehicles.Find(vehicleid);
                if (existing == null)
                    return "Vehicle not found.";

                SPContext.Vehicles.Remove(existing);
                SPContext.SaveChanges();
                return "Vehicle deleted successfully.";
            }
            catch (Exception ex)
            {
                _errorhandling.Add(ex, "Error in DeleteVehicle");
                return "Error deleting vehicle.";
            }
        }

        public string UpdateVehicle(UpdateVehicleDTO update)
        {
            try
            {
                var existingVehicle = SPContext.Vehicles
                    .FirstOrDefault(v => v.Vehicleid == update.Vehicleid);

                if (existingVehicle == null)
                    return "Vehicle not found";

                existingVehicle.Registrationnumber = update.Registrationnumber;
                existingVehicle.Model = update.Model;
                existingVehicle.Manufacturer = update.Manufacturer;
                existingVehicle.Year = update.Year;
                existingVehicle.Capacity = update.Capacity;
                existingVehicle.Status = update.Status;

                SPContext.SaveChanges();
                return "Vehicle updated successfully";
            }
            catch (Exception ex)
            {
                _errorhandling.Add(ex, "Error updating Vehicle");
                return "Error updating vehicle";
            }
        }

        public List<Vehicle> GetAllVehicles()
        {
            try
            {
                return SPContext.Vehicles.ToList();
            }
            catch (Exception ex)
            {
                return new List<Vehicle>();
            }
        }
    }
}
