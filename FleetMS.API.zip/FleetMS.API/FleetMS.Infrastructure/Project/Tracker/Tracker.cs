﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FleetMS.Application;
using FleetMS.Application.DTO.Tracker;
using FleetMS.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;

namespace FleetMS.Infrastructure.Project.Tracker
{
    public class Tracker : ITracker
    {
        private readonly ErrorHandler _errorhandling;
        private readonly StarkPradeepContext SPContext;
        public Tracker(StarkPradeepContext _SPContext, ErrorHandler errors)
        {
            SPContext = _SPContext;
            _errorhandling = errors;
        }

        public List<TrackDriverDTO> GetAllDetails(int driverid)
        {
            try
            {
                var query = SPContext.Drivers
                    .Include(x => x.Vehicles)
                        .ThenInclude(y => y.Trips)
                    .AsQueryable();

                if (driverid > 0)
                {
                    query = query.Where(z => z.Driverid == driverid);
                }

                var Data = query
                    .Select(z => new TrackDriverDTO()
                    {
                        Driverid = z.Driverid,
                        Name = z.Name,
                        VehicleInfo = z.Vehicles.Select(vehicle => new TrackVehicleDTO
                        {
                            Trips = vehicle.Trips.Select(t => t.Status).ToList(),
                            Vehicle = vehicle.Year // Ensure this matches the correct property type
                        }).ToList()
                    });

                return Data.ToList();
            }
            catch (Exception ex)
            {
                _errorhandling.Add(ex, "Success");
                return new List<TrackDriverDTO>();
            }
        }

        public string DeleteVehicle(int vehicleid)
        {
            try
            {
                var existing = SPContext.Vehicles.Find(vehicleid);
                if (existing == null)
                    return "Vehicle not found.";

                SPContext.Vehicles.Remove(existing);
                SPContext.SaveChanges();
                return "Vehicle deleted successfully.";
            }
            catch (Exception ex)
            {
                _errorhandling.Add(ex, "Error in DeleteVehicle");
                return "Error deleting vehicle.";
            }
        }
    }
}
