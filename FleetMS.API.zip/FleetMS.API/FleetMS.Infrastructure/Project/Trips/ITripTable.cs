﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FleetMS.Application.DTO.Aggregate;
using FleetMS.Application.DTO.Tracker;
using FleetMS.Application.DTO.Trip;

namespace FleetMS.Infrastructure.Project.Trips
{
    public interface ITripTable
    {
        public List<GetTripDTO> GetAllTrips();

        public string DeleteTrip(int tripid);

        public string UpdateTrip(UpdateTripDTO update);

        public string AddTrip(CreateTripDTO create);
    }
}
