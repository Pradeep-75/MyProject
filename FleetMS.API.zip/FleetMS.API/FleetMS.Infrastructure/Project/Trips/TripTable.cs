﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FleetMS.Application;
using FleetMS.Application.DTO.Trip;
using FleetMS.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;
using FleetMS.Application.DTO.Tracker;
using FleetMS.Application.DTO.Aggregate;

namespace FleetMS.Infrastructure.Project.Trips
{
    public class TripTable : ITripTable
    {
        private readonly ErrorHandler _errorhandling;
        private readonly StarkPradeepContext SPContext;
        public TripTable(StarkPradeepContext UserTable, ErrorHandler errors)
        {
            SPContext = UserTable;
            _errorhandling = errors;
        }

        public List<GetTripDTO> GetAllTrips()
        {
            try
            {
                return SPContext.Trips
                    .Select(t => new GetTripDTO
                    {
                        Tripid = t.Tripid,
                        Vehicleid = t.Vehicleid,
                        Startlocation = t.Startlocation,
                        Endlocation = t.Endlocation,
                        Distancekm = t.Distancekm,
                        Status = t.Status,
                        Createdon = t.Createdon,
                        Createdby = t.Createdby,
                        Modifiedby = t.Modifiedby,
                        Modifiedon = t.Modifiedon
                    }).ToList();
            }
            catch (Exception ex)
            {
                _errorhandling.Add(ex, "Error fetching trips");
                return new List<GetTripDTO>();
            }
        }

        public string DeleteTrip(int tripid)
        {
            try
            {
                var trip = SPContext.Trips.FirstOrDefault(t => t.Tripid == tripid);
                if (trip == null) return "Trip not found";

                SPContext.Trips.Remove(trip);
                SPContext.SaveChanges();

                return "Trip deleted successfully";
            }
            catch (Exception ex)
            {
                _errorhandling.Add(ex, "Error deleting trip");
                return "Error deleting trip";
            }
        }

        public string AddTrip(CreateTripDTO create)
        {
            try
            {
                var trip = new Trip
                {
                    Vehicleid = create.Vehicleid,
                    Startlocation = create.Startlocation,
                    Endlocation = create.Endlocation,
                    Distancekm = create.Distancekm,
                    Status = string.IsNullOrEmpty(create.Status) ? "Pending" : create.Status,
                    Createdon = create.Createdon.HasValue
                            ? DateTime.SpecifyKind(create.Createdon.Value, DateTimeKind.Utc)
                            : DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc),

                    Createdby = create.Createdby
                };

                SPContext.Trips.Add(trip);
                SPContext.SaveChanges();

                return "Trip added successfully";
            }
            catch (Exception ex)
            {
                _errorhandling.Add(ex, "Error adding trip");
                return $"Error adding trip: {ex.Message}";
            }
        }

        public string UpdateTrip(UpdateTripDTO update)
        {
            try
            {
                var existingTrips = SPContext.Trips
                    .FirstOrDefault(v => v.Tripid == update.Tripid);

                if (existingTrips == null)
                    return "Trip not found";

                existingTrips.Startlocation = update.Startlocation;
                existingTrips.Endlocation = update.Endlocation;
                existingTrips.Distancekm = update.Distancekm;
                existingTrips.Status = update.Status;

                SPContext.SaveChanges();
                return "Trip updated successfully";
            }
            catch (Exception ex)
            {
                _errorhandling.Add(ex, "Error updating Trip");
                return "Error updating Trip";
            }
        }
    }
}
