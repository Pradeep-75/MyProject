﻿namespace FleetMS.Service
{
    public class ServiceClass
    {

    }
}
